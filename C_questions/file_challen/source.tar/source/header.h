/* Header for the BST*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

typedef struct BST {
	int count;
	int ln;
	struct BST *left;
	struct BST *right;
	//char *str;
	char str[20];
}NODE;

int integervalidation(void);
int sum_all (NODE*);


int str_atoi(char *);

NODE *insert_BST(NODE *, char *,int);

void traverse_preorder(NODE *);

void traverse_inorder(NODE *);

void traverse_postorder(NODE *);

NODE *delete_BST(NODE*, int);

NODE *max_bst(NODE *);

NODE *min_bst(NODE *);

void level_order(NODE * );

void print_level(NODE *, int);

int height ( NODE *);

NODE *mirror(NODE *);
